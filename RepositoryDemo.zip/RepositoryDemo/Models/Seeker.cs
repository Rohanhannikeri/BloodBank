﻿using System.ComponentModel.DataAnnotations;

namespace CRUDDemo.Models
{
    public class Seeker
    {
        [Key]
        public int SeekerId { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public string BloodGroup{ get; set; }
       
        public string Gender { get; set; }
        

    }
}
