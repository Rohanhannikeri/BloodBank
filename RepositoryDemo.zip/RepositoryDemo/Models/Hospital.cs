﻿using System.ComponentModel.DataAnnotations;

namespace BloodLaboratory_Project.Models
{
    public class Hospital
    {
        [Key]
        public int HospitalID { get; set; }
        public string Name { get; set; }    
        public string Email { get; set; }

        public string City { get; set; }


    }
}
