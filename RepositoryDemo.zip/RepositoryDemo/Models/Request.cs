﻿using System.ComponentModel.DataAnnotations;

namespace BloodLaboratory_Project.Models
{
    public class Request
    {
        [Key]
        public int RequestId { get; set; }
       

        public string MemberType { get; set; }
        public string MemberName { get; set; }
        public string RequiredBlood { get; set; }
        public int Quantity { get; set; }
        public int ContactNo { get; set; }


    }
}
