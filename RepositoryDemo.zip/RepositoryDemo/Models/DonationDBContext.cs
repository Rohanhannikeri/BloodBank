﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;
using BloodLaboratory_Project.Models;

namespace CRUDDemo.Models
{
    public class DonationDBContext: DbContext
    {
        public DonationDBContext(DbContextOptions<DonationDBContext> options) : base(options)
        {

        }
        public DbSet<Seeker> Seekers { get; set; }
        public DbSet<Request> Requests { get; set; }
        public DbSet<Donor> Donors { get; set; }
        public DbSet<Hospital> Hospitals { get; set; }
        public DbSet<BloodBank> BloodBank { get; set; }
        public DbSet<BloodStock> BloodStock { get; set; }
    }
}
