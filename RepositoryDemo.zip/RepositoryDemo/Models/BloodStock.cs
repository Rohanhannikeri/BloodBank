﻿using System.ComponentModel.DataAnnotations;

namespace BloodLaboratory_Project.Models
{
    public class BloodStock
    {
        [Key]
        public int StockId { get; set; }
        public string BloodGroup { get; set; }
        public string Status { get; set; }
        

    }
}
