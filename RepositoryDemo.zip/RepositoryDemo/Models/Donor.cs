﻿using System.ComponentModel.DataAnnotations;

namespace BloodLaboratory_Project.Models
{
    public class Donor
    {
        [Key]
        public int DonorId { get; set; }
        public string Name { get; set; }
        public string BloodGroup { get; set; }

    }
}
