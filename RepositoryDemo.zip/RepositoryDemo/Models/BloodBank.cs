﻿using System.ComponentModel.DataAnnotations;

namespace BloodLaboratory_Project.Models
{
    public class BloodBank
    {
        [Key]
        public int BloodBankId { get; set; }
        public string Name { get; set; }   
        public int BloodBankNumber { get; set; }
        public string Email { get; set; }

    }
}
