﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CRUDDemo.Models;

namespace BloodLaboratory_Project.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SeekersController : ControllerBase
    {
        private readonly DonationDBContext _context;

        public SeekersController(DonationDBContext context)
        {
            _context = context;
        }

        // GET: api/Seekers
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Seeker>>> GetSeekers()
        {
          if (_context.Seekers == null)
          {
              return NotFound();
          }
            return await _context.Seekers.ToListAsync();
        }

        // GET: api/Seekers/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Seeker>> GetSeeker(int id)
        {
          if (_context.Seekers == null)
          {
              return NotFound();
          }
            var seeker = await _context.Seekers.FindAsync(id);

            if (seeker == null)
            {
                return NotFound();
            }

            return seeker;
        }

        // PUT: api/Seekers/5
       
        [HttpPut("{id}")]
        public async Task<IActionResult> PutSeeker(int id, Seeker seeker)
        {
            if (id != seeker.SeekerId)
            {
                return BadRequest();
            }

            _context.Entry(seeker).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!SeekerExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Seekers

        [HttpPost]
        public async Task<ActionResult<Seeker>> PostSeeker(Seeker seeker)
        {
          if (_context.Seekers == null)
          {
              return Problem("Entity set 'DonationDBContext.Seekers'  is null.");
          }
            _context.Seekers.Add(seeker);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetSeeker", new { id = seeker.SeekerId }, seeker);
        }

        // DELETE: api/Seekers/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteSeeker(int id)
        {
            if (_context.Seekers == null)
            {
                return NotFound();
            }
            var seeker = await _context.Seekers.FindAsync(id);
            if (seeker == null)
            {
                return NotFound();
            }

            _context.Seekers.Remove(seeker);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool SeekerExists(int id)
        {
            return (_context.Seekers?.Any(e => e.SeekerId == id)).GetValueOrDefault();
        }
    }
}
