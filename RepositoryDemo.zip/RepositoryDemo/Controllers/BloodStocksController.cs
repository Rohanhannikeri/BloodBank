﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BloodLaboratory_Project.Models;
using CRUDDemo.Models;

namespace BloodLaboratory_Project.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BloodStocksController : ControllerBase
    {
        private readonly DonationDBContext _context;

        public BloodStocksController(DonationDBContext context)
        {
            _context = context;
        }

        // GET: api/BloodStocks
        [HttpGet]
        public async Task<ActionResult<IEnumerable<BloodStock>>> GetBloodStock()
        {
          if (_context.BloodStock == null)
          {
              return NotFound();
          }
            return await _context.BloodStock.ToListAsync();
        }

        // GET: api/BloodStocks/5
        [HttpGet("{id}")]
        public async Task<ActionResult<BloodStock>> GetBloodStock(int id)
        {
          if (_context.BloodStock == null)
          {
              return NotFound();
          }
            var bloodStock = await _context.BloodStock.FindAsync(id);

            if (bloodStock == null)
            {
                return NotFound();
            }

            return bloodStock;
        }

        // PUT: api/BloodStocks/5
       
        [HttpPut("{id}")]
        public async Task<IActionResult> PutBloodStock(int id, BloodStock bloodStock)
        {
            if (id != bloodStock.StockId)
            {
                return BadRequest();
            }

            _context.Entry(bloodStock).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!BloodStockExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/BloodStocks
 
        [HttpPost]
        public async Task<ActionResult<BloodStock>> PostBloodStock(BloodStock bloodStock)
        {
          if (_context.BloodStock == null)
          {
              return Problem("Entity set 'DonationDBContext.BloodStock'  is null.");
          }
            _context.BloodStock.Add(bloodStock);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetBloodStock", new { id = bloodStock.StockId }, bloodStock);
        }

        // DELETE: api/BloodStocks/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteBloodStock(int id)
        {
            if (_context.BloodStock == null)
            {
                return NotFound();
            }
            var bloodStock = await _context.BloodStock.FindAsync(id);
            if (bloodStock == null)
            {
                return NotFound();
            }

            _context.BloodStock.Remove(bloodStock);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool BloodStockExists(int id)
        {
            return (_context.BloodStock?.Any(e => e.StockId == id)).GetValueOrDefault();
        }
    }
}
