﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BloodLaboratory_Project.Models;
using CRUDDemo.Models;

namespace BloodLaboratory_Project.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BloodBanksController : ControllerBase
    {
        private readonly DonationDBContext _context;

        public BloodBanksController(DonationDBContext context)
        {
            _context = context;
        }

        // GET: api/BloodBanks
        [HttpGet]
        public async Task<ActionResult<IEnumerable<BloodBank>>> GetBloodBank()
        {
          if (_context.BloodBank == null)
          {
              return NotFound();
          }
            return await _context.BloodBank.ToListAsync();
        }

        // GET: api/BloodBanks/5
        [HttpGet("{id}")]
        public async Task<ActionResult<BloodBank>> GetBloodBank(int id)
        {
          if (_context.BloodBank == null)
          {
              return NotFound();
          }
            var bloodBank = await _context.BloodBank.FindAsync(id);

            if (bloodBank == null)
            {
                return NotFound();
            }

            return bloodBank;
        }

        // PUT: api/BloodBanks/5
       
        [HttpPut("{id}")]
        public async Task<IActionResult> PutBloodBank(int id, BloodBank bloodBank)
        {
            if (id != bloodBank.BloodBankId)
            {
                return BadRequest();
            }

            _context.Entry(bloodBank).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!BloodBankExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/BloodBanks
       
        [HttpPost]
        public async Task<ActionResult<BloodBank>> PostBloodBank(BloodBank bloodBank)
        {
          if (_context.BloodBank == null)
          {
              return Problem("Entity set 'DonationDBContext.BloodBank'  is null.");
          }
            _context.BloodBank.Add(bloodBank);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetBloodBank", new { id = bloodBank.BloodBankId }, bloodBank);
        }

        // DELETE: api/BloodBanks/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteBloodBank(int id)
        {
            if (_context.BloodBank == null)
            {
                return NotFound();
            }
            var bloodBank = await _context.BloodBank.FindAsync(id);
            if (bloodBank == null)
            {
                return NotFound();
            }

            _context.BloodBank.Remove(bloodBank);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool BloodBankExists(int id)
        {
            return (_context.BloodBank?.Any(e => e.BloodBankId == id)).GetValueOrDefault();
        }
    }
}
